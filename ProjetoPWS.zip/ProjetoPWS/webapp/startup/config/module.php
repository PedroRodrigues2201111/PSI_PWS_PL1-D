<?php
// Web Module Configuration
// A web module requires an entry in the middleware/froncontroller
// ServerMod
// registerServerMod

define('WL_SERVER_URL',                         'http://localhost/');
define('WL_SERVER_MOD_NAME',                    'webapp');
define('WL_SERVER_PUBLIC_DIR_NAME',             'public');
define('WL_RUNNING_ENV',                        'dev');
define('WL_DEBUG_ENABLED',                       true);
define('WL_DEFAULT_LANGUAGE',                   'en');
