<?php

$defaultDbConnection = array (
    'DBMS'          => 'mysql',
    'SERVER'        => 'localhost',
    'PORT'          => '3306',
    'DATABASENAME'  => 'webapp',
    'USER'          => 'root',
    'PASSWORD'      => '',
    'CHARSET'       => 'utf8',
    'COLLATION'     => 'utf8_unicode_ci',
);