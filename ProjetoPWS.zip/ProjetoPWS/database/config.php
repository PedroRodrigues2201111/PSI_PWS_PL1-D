<?php
// Constantes de configuração da conexão com o banco de dados
define("SERVIDOR","localhost");
define("UTILIZADOR","root");
define("PALAVRAPASSE","");
define("BASE","bdprojetopws");

?>
