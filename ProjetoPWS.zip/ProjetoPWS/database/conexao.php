<?php
include("config.php");

$conexao = mysqli_connect(SERVIDOR,UTILIZADOR,PALAVRAPASSE,BASE) or die("Erro na conexão com o servidor!" . mysqli_connect_error());

?>
