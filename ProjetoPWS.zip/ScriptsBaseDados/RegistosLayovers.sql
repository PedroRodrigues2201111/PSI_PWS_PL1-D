/*
-- Query: SELECT * FROM webapp.layovers
-- Date: 2021-06-21 23:38
*/
INSERT INTO `` (`id`,`idairportfrom`,`idairporttoo`,`idflight`,`distance`,`price`,`dtorigin`,`dtdestination`,`hrorigin`,`hrdestination`) VALUES (1,6,6,2,'40','160','2020-03-12','2020-03-14','09:00:00','12:00:00');
INSERT INTO `` (`id`,`idairportfrom`,`idairporttoo`,`idflight`,`distance`,`price`,`dtorigin`,`dtdestination`,`hrorigin`,`hrdestination`) VALUES (2,6,6,4,'40','160','2020-03-12','2020-03-14','09:00:00','12:00:00');
INSERT INTO `` (`id`,`idairportfrom`,`idairporttoo`,`idflight`,`distance`,`price`,`dtorigin`,`dtdestination`,`hrorigin`,`hrdestination`) VALUES (3,6,6,4,'40','160','2020-03-12','2020-03-14','09:00:00','12:00:00');
INSERT INTO `` (`id`,`idairportfrom`,`idairporttoo`,`idflight`,`distance`,`price`,`dtorigin`,`dtdestination`,`hrorigin`,`hrdestination`) VALUES (4,6,6,5,'40','160','2020-03-12','2020-03-14','09:00:00','12:00:00');
