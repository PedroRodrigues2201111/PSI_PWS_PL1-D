/*
-- Query: SELECT * FROM webapp.users
-- Date: 2021-06-21 23:39
*/
INSERT INTO `` (`id`,`name`,`morada`,`email`,`nif`,`telefone`,`username`,`password`,`role`) VALUES (1,'Pedro Rodrigues','Rua Doutor Bravo Serra','pedrorodrigues.fx18@gmail.com','123123123','934077828','passageiro','123','passageiro');
INSERT INTO `` (`id`,`name`,`morada`,`email`,`nif`,`telefone`,`username`,`password`,`role`) VALUES (7,'Pedro Rodrigues','Rua Doutor Bravo Serra, NÂ°26 -Cernache Do Bonjardim, SertÃ£, Castelo Branco','pedrorodrigues.fx18@gmail.com','123123123','934077827','admin','123','admin');
INSERT INTO `` (`id`,`name`,`morada`,`email`,`nif`,`telefone`,`username`,`password`,`role`) VALUES (3,'Pedro Rodrigues','Rua Doutor Bravo Serra, NÂ°26 -Cernache Do Bonjardim, SertÃ£, Castelo Branco','pedrorodrigues.fx18@gmail.com','123123999','934077827','gestorvoo','123','gestorvoo');
INSERT INTO `` (`id`,`name`,`morada`,`email`,`nif`,`telefone`,`username`,`password`,`role`) VALUES (6,'Pedro Rodrigues','Rua Doutor Bravo Serra, NÂ°26 -Cernache Do Bonjardim, SertÃ£, Castelo Branco','pedrorodrigues.fx18@gmail.com','123123123','934077827','operadorcheckin','123','operadorcheckin');
