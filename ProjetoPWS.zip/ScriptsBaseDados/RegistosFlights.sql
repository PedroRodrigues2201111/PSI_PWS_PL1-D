/*
-- Query: SELECT * FROM webapp.flights
-- Date: 2021-06-21 23:37
*/
INSERT INTO `` (`id`,`idairportorigin`,`idairportdestination`,`dtorigin`,`dtdestination`,`hrorigin`,`hrdestination`,`precoida`,`precoidaevolta`,`tipopassagem`,`metodopagamento`,`origem`,`destino`) VALUES (7,NULL,NULL,'2020-03-12','2020-03-14','09:00:00','12:00:00','50','100','',NULL,'Lisboa','Porto');
INSERT INTO `` (`id`,`idairportorigin`,`idairportdestination`,`dtorigin`,`dtdestination`,`hrorigin`,`hrdestination`,`precoida`,`precoidaevolta`,`tipopassagem`,`metodopagamento`,`origem`,`destino`) VALUES (9,NULL,NULL,'2020-03-19','2020-03-21','22:00:00','07:00:00',NULL,NULL,NULL,NULL,'Lisboa','Faro');
INSERT INTO `` (`id`,`idairportorigin`,`idairportdestination`,`dtorigin`,`dtdestination`,`hrorigin`,`hrdestination`,`precoida`,`precoidaevolta`,`tipopassagem`,`metodopagamento`,`origem`,`destino`) VALUES (10,NULL,NULL,'2020-05-23','2020-05-24','13:30:00','16:00:00',NULL,NULL,NULL,NULL,'Porto','Faro');
