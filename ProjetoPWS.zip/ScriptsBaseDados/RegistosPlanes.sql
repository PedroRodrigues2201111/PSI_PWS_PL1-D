/*
-- Query: SELECT * FROM webapp.planes
-- Date: 2021-06-21 23:38
*/
INSERT INTO `` (`id`,`reference`,`capacity`,`type`) VALUES (2,'A11004','40','airbus A330');
INSERT INTO `` (`id`,`reference`,`capacity`,`type`) VALUES (3,'A12446','45','airbus A547');
