/*
-- Query: SELECT * FROM webapp.airports
-- Date: 2021-06-21 23:36
*/
INSERT INTO `` (`id`,`name`,`localization`,`contact`,`country`) VALUES (7,'Aeroporto Humberto Delgado','Lisboa','274564789','Portugal');
INSERT INTO `` (`id`,`name`,`localization`,`contact`,`country`) VALUES (6,'Pedro Rodrigues','Porto','934077828','Portugal');
