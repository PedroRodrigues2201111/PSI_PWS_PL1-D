USE webapp;

-- Criação da tabela aeroportos
CREATE TABLE `airports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `localization` varchar(45) DEFAULT NULL,
  `contact` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Criação da tabela voos
CREATE TABLE `flights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idairportorigin` int(11) DEFAULT NULL,
  `idairportdestination` int(11) DEFAULT NULL,
  `dtorigin` date DEFAULT NULL,
  `dtdestination` date DEFAULT NULL,
  `hrorigin` time DEFAULT NULL,
  `hrdestination` time DEFAULT NULL,
  `precoida` varchar(45) DEFAULT NULL,
  `precoidaevolta` varchar(45) DEFAULT NULL,
  `tipopassagem` varchar(45) DEFAULT NULL,
  `metodopagamento` varchar(45) DEFAULT NULL,
  `origem` varchar(45) DEFAULT NULL,
  `destino` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Criação da tabela escalas
CREATE TABLE `layovers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idairportfrom` int(11) DEFAULT NULL,
  `idairporttoo` int(11) DEFAULT NULL,
  `idflight` int(11) DEFAULT NULL,
  `distance` varchar(45) DEFAULT NULL,
  `price` varchar(45) DEFAULT NULL,
  `dtorigin` date DEFAULT NULL,
  `dtdestination` date DEFAULT NULL,
  `hrorigin` time DEFAULT NULL,
  `hrdestination` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idairportfrom_idx` (`idairportfrom`),
  KEY `idairporttoo_idx` (`idairporttoo`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Criação da tabela aviões
CREATE TABLE `planes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(45) DEFAULT NULL,
  `capacity` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Criação da tabela utilizadores
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) DEFAULT NULL,
  `morada` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `nif` varchar(9) DEFAULT NULL,
  `telefone` varchar(9) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `role` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;